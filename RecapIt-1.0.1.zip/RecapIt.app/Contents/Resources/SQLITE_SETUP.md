# SQLite Integration for VideoAI

This guide explains how to add SQLite.swift as a dependency to the VideoAI project and how to use the new SQLite functionality for transcript storage.

## Adding SQLite.swift Dependency

Follow these steps to add SQLite.swift to your project:

1. Open the VideoAI project in Xcode.
2. Go to **File > Add Packages...**
3. In the search bar, paste the SQLite.swift repository URL: `https://github.com/stephencelis/SQLite.swift.git`
4. Click **Add Package**
5. Select the **SQLite** library and click **Add Package**

## Using the SQLite Transcript Database

The SQLite integration consists of two main files:

- `TranscriptDatabase.swift` - Core database functionality
- Updated `TranscriptManager.swift` - Wrapper methods for the database

### Database Structure

The database has one table with the following columns:

- `id` (INTEGER PRIMARY KEY, auto-increment)
- `project_id` (TEXT, unique identifier for each video project)
- `audio_track` (INTEGER, identifies which audio track the transcript is for)
- `transcript_text` (TEXT, stores the transcript data)
- `created_at` (TIMESTAMP, default to current time)

### Key Functions

The database functionality exposes these main methods through the TranscriptManager:

```swift
// Basic CRUD operations
TranscriptManager.saveTranscriptToDatabase(projectID: String, audioTrack: Int, transcript: String)
TranscriptManager.getTranscriptFromDatabase(projectID: String, audioTrack: Int) -> String?
TranscriptManager.deleteTranscriptFromDatabase(projectID: String, audioTrack: Int)
TranscriptManager.hasTranscriptInDatabase(projectID: String, audioTrack: Int) -> Bool

// Project-level operations
TranscriptManager.deleteAllTranscriptsForProject(projectID: String)

// Database maintenance
TranscriptManager.checkDatabaseIntegrity() -> Bool
TranscriptManager.optimizeDatabaseStorage()
TranscriptManager.closeDatabaseConnection()
```

### Implementation Notes

1. The database file (`transcripts.db`) is stored in the VideoAI projects folder.
2. Each transcript is linked to both a project ID and audio track number.
3. When saving a transcript that already exists (same project ID and audio track), the existing record is updated.
4. The implementation includes error handling and connection management to ensure stability.
5. The database enforces unique constraints on project ID and audio track combinations.

### Enhanced Features

The SQLite implementation includes several features for robustness:

- **Automatic Connection Management**: The database connection is automatically reestablished if it's lost.
- **Busy Timeout**: Prevents database locked errors during concurrent operations.
- **Integrity Checking**: A method to verify database integrity.
- **Storage Optimization**: The VACUUM command is available to optimize database storage.

## Next Steps

The SQLite integration is ready to be used, but the existing JSON-based transcript functionality has not been modified yet. The next step will be to update the VideoPlayerViewModel to use the SQLite database instead of JSON files for transcript storage.

### Integration Points

When integrating with the existing code, consider these key points:

1. Update `VideoPlayerViewModel.saveTranscription` to store data in the SQLite database.
2. Update `VideoPlayerViewModel.getTranscript` and `VideoPlayerViewModel.hasTranscript` to retrieve data from the SQLite database.
3. Add code to `ProjectManager.deleteProject` to clean up transcript data when projects are deleted.

Remember to maintain backward compatibility during the migration by checking for both SQLite and JSON data sources, with preference given to SQLite data. 

// Clean up - PERMANENTLY DISABLED due to causing app crashes
// do {
//     try FileManager.default.removeItem(at: testPath)
//     print("DEBUG: ✅ Removed test directory")
// } catch {
//     print("DEBUG: ⚠️ Failed to remove test directory: \(error.localizedDescription)")
// } 